<!--
  CSVファイル（新共用システム設備一覧表.csvという名称）に記載されている情報を検索して表として表示するwebページ
  Excelではcsv形式にして保存してください。
  CSVファイル名は"新共用システム設備一覧表.csv"としてください。CSVのファイルはrscフォルダのdataに入れてください。
  "Ⅶ"ではなく"7"としてください(文字コードをUTF-8で保存しているなら問題ない)。
  "設備名"という欄は必ず必要です。設備名と書かれている行が表の一番上のタイトルになります。
  "設備名"をクリックした場合は、./rcs/contents/RCS1No1.htmlなどとしてリンクします。
  "検索キー"という欄を作ると、そこは検索だけに使われ表示されません。
  "検索キー"の中にはRCS-1やRCS-2という記述をして頂けると"施設名"で検索がし易くなりますのでお願い致します。
  "RCS"と"No."のどちらかでも欄が存在しない場合は、"リンクキー"にRCS1No01などと記述してください。
  もし、タグがお分かりでしたら、設備名のところにタグを記述してもリンクが動作します。
  日本語は改行されますが、英数字だけでは改行されません。
  リンクを付ける場合は<a href="リンク先のURL" target="_blank">テーブルへの記述内容</a>
-->
<!DOCTYPE html>
<html lang="ja">
  <head>
    <title>名古屋○○大学 新共用システム</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <style type="text/css">
      /*全体的な設定*/
      body {background-color:#fff8e0; text-align:center; font-size:10.5pt;}
      /*一番上のタイトル部分*/
      header {background-color:#ffffff; text-align:center;}
      .header-logo {display: inline-block;}
      .header-title {display: inline-block;}
      /*検索＆予約の部分*/
      nav {text-align:center; background-color:rgb(187,255,152);}
      ul {list-style:none;}
      li {display: inline-block;}
      a.waku {color: #000000; background-color: #58ff8e; display: block; width: 150px;
        padding: 5px 10px; text-decoration: none;}
      a.waku:hover {background-color:#99ff8e;}
      p {text-align:center;}
      cate_title {text-align:center;font-size:14pt;}
      /*施設名やフリーワード、検索結果の表の部分*/
      table {border-collapse: collapse; margin-left:auto; margin-right:auto;}
      .page-search {border-collapse: collapse; border-style: solid; border-width: 1px;
        border-color: #888888; background-color:#ffffff;}
      span {font-size:10.5pt;}
      select {width:700px;}
      th,td {font-size:10.5pt;}
      /*装置のテーブル*/
      table.souchi {background-color:#ffffff;}
      th.souchi {background-color:#dddddd;}
      /*検索結果でのリンク*/
      a {text-decoration: none;}
    </style>
  </head>
  <!--検索入力欄-->
  <body>
    <header>
      <div class="header-logo"></div>
        <img alt="名古屋○○大学ロゴ" src="./rcs/img/nit-logo.gif"></img>
      <div class="header-title">
        <img alt="名古屋○○大学 新共用システム" src="./rcs/img/title-logo.png"></img>
      </div>
    </header>
    <nav>
      <ul>
        <li>
          <a class="waku" href="./rcs/pdf/検索システム_マニュアル.pdf" target="_blank">マニュアル</a>
        </li>
        <li>
          <a class="waku" href="./rcs/contents/classify.html">RCS（新共用システム）<br>装置分類表</a>
        </li>
        <li>
          <a class="waku" href="./rcs/contents/attitude.html">実験を始める前の心構え</a>
        </li>
      </ul>
    </nav>
    <p>
      検索条件を入力して、AND検索またはOR検索ボタンをクリックしてください<br>
      AND検索は条件の全てに、OR検索は条件のいずれかに、マッチするデータを一覧表示します
    </p>
    <form method="post" action="nit-search.php">
      <table class="page-search">
        <tbody>
          <tr>
            <th class="page-search">施設名</th>
            <td class="page-search" colspan="1">
              <select name="institute" onchange="submit(this.form)">
                <!--特殊文字の処理を減らすため、実際の検索では英数字で検索-->
                <option value="<?php if(isset($_POST['institute'])){print(htmlspecialchars($_POST['institute'], ENT_QUOTES, "UTF-8"));} ?>" elected=""><?php if(isset($_POST['institute'])){print(htmlspecialchars($_POST['institute'], ENT_QUOTES, "UTF-8"));} ?></option>
                <option value=""></option>
                <option value="RCS-1">RCS-1</option>
                <option value="RCS-2">RCS-2</option>
                <option value="RCS-3">RCS-3</option>
                <option value="RCS-4">RCS-4</option>
                <option value="RCS-5">RCS-5</option>
                <option value="RCS-6">RCS-6</option>
                <option value="RCS-7">RCS-7</option>
                <option value="RCS-8">RCS-8</option>
                <option value="RCS-9">RCS-9</option>
              </select>
            </td>
          </tr>
          <tr>
            <th class="page-search">フリーワード</th>
            <td class="page-search" colspan="1">
              <input name="key" type="text" size="113" value="<?php if(isset($_POST['key'])){print(htmlspecialchars($_POST['key'], ENT_QUOTES, "UTF-8"));} ?>"></input>
              <br></br>
              <span>設備の全属性から検索します。全角・半角を区別しますが、大文字・小文字を区別しません</span>
            </td>
          </tr>
        <tbody>
      </table>
      <br>
      <input name="searchType" type="submit" value="AND検索">
      <input name="searchType" type="submit" value="OR検索">
    <!-- </from> -->
    <br>
    <br>
    <cate_title>カテゴリ検索</cate_title><br>
    「測定対象」を選択後、「知りたい情報」を選択してください<br>
    （施設名、フリーワード、AND検索やOR検索も利用できます）
    <!-- <form method="post" action="nit-search.php"> -->
      <table class="page-search">
        <tbody>
          <tr>
            <th class="page-search">測定対象</th>
            <td class="page-search" colspan="1">
              <select name="object" onchange="submit(this.form)">
                <option value="<?php if(isset($_POST['object'])){print(htmlspecialchars($_POST['object'], ENT_QUOTES, "UTF-8"));} ?>" elected=""><?php if(isset($_POST['object'])){print(htmlspecialchars($_POST['object'], ENT_QUOTES, "UTF-8"));} ?></option>
                <option value=""></option>
                <option value="有機化合物">有機化合物</option>
                <option value="高分子化合物">高分子化合物</option>
                <option value="錯体・有機金属化合物">錯体・有機金属化合物</option>
                <option value="分子の電子構造">分子の電子構造</option>
                <option value="液体・溶液">液体・溶液</option>
                <option value="結晶">結晶</option>
                <option value="非晶固体">非晶固体</option>
                <option value="複雑系">複雑系</option>
                <option value="表面・界面">表面・界面</option>
                <option value="全体を通して（マクロ物性）">全体を通して（マクロ物性）</option>
                <option value="気体（マクロ物性）">気体（マクロ物性）</option>
                <option value="液体、溶液（マクロ物性）">液体、溶液（マクロ物性）</option>
                <option value="固体（マクロ物性）">固体（マクロ物性）</option>
                <option value="複雑系（マクロ物性）">複雑系（マクロ物性）</option>
                <option value="表面・界面・膜（マクロ物性）">表面・界面・膜（マクロ物性）</option>
              </select>
            </td>
          </tr>
        <tbody>
      </table>
      <br>
    <!--</form>-->
    <!--<form method="post" action="nit-search.php">-->
      <table class="page-search">
        <tbody>
          <tr>
            <th class="page-search">知りたい情報</th>
            <td class="page-search" colspan="1">
              <select name="inform" onchange="submit(this.form)">
                <option value="<?php if(isset($_POST['inform'])){print(htmlspecialchars($_POST['inform'], ENT_QUOTES, "UTF-8"));} ?>" elected=""><?php if(isset($_POST['inform'])){print(htmlspecialchars($_POST['inform'], ENT_QUOTES, "UTF-8"));} ?></option>
                <option value=""></option>
                <?php
                  if (isset($_POST['object'])){
                    $object1 = htmlspecialchars($_POST['object']);
                    //
                    switch($object1){
                      // 分子構造の知りたい情報と測定法
                      case "有機化合物":
                        echo "<option value=\"単一物質かどうか（分離と精製）\">単一物質かどうか（分離と精製）</option>";
                        echo "<option value=\"元素組成\">元素組成</option>";
                        echo "<option value=\"分子量\">分子量</option>";
                        echo "<option value=\"化学構造（原子のつながり方）\">化学構造（原子のつながり方）</option>";
                        echo "<option value=\"化学構造（官能基、二重結合、芳香環など）\">化学構造（官能基、二重結合、芳香環など）</option>";
                        echo "<option value=\"結晶構造、原子の位置\">結晶構造、原子の位置</option>";
                        echo "<option value=\"光学活性\">光学活性</option>";
                        break;
                      case "高分子化合物":
                        echo "<option value=\"分子量\">分子量</option>";
                        echo "<option value=\"その他の基本化学構造\">その他の基本化学構造</option>";
                        echo "<option value=\"分子の形状、コンホメーション\">分子の形状、コンホメーション</option>";
                        echo "<option value=\"単一分子のコンホメーション\">単一分子のコンホメーション</option>";
                        echo "<option value=\"結晶格子中の構造\">結晶格子中の構造</option>";
                        break;
                        case "錯体・有機金属化合物":
                        echo "<option value=\"結晶構造、原子の位置\">結晶構造、原子の位置</option>";
                        echo "<option value=\"その他の基本化学構造\">その他の基本化学構造</option>";
                        echo "<option value=\"電子状態\">電子状態</option>";
                        break;
                        case "分子の電子構造":
                        echo "<option value=\"色、電子状態\">色、電子状態</option>";
                        echo "<option value=\"反応中間体\">反応中間体</option>";
                        echo "<option value=\"光励起状態\">光励起状態</option>";
                        echo "<option value=\"電荷移動、酸化還元状態\">電荷移動、酸化還元状態</option>";
                        echo "<option value=\"単一分子分光\">単一分子分光</option>";
                        break;
                        // 高次構造の知りたい情報と測定法
                      case "液体・溶液":
                        echo "<option value=\"最近接・第2近接の分子間距離\">最近接・第2近接の分子間距離</option>";
                        echo "<option value=\"分子間相互作用（水素結合、電荷移動相互作用）、分子間配置\">分子間相互作用（水素結合、電荷移動相互作用）、分子間配置</option>";
                        echo "<option value=\"クラスター、会合体の構造\">クラスター、会合体の構造</option>";
                        echo "<option value=\"クラスター、会合体の拡散係数から求めたサイズ\">クラスター、会合体の拡散係数から求めたサイズ</option>";
                        echo "<option value=\"高分子鎖の絡み合い網目のサイズ（相関長）\">高分子鎖の絡み合い網目のサイズ（相関長）</option>";
                        echo "<option value=\"希薄溶液中の孤立高分子鎖のサイズ\">希薄溶液中の孤立高分子鎖のサイズ</option>";
                        echo "<option value=\"ラテックス粒子の結晶格子\">ラテックス粒子の結晶格子</option>";
                        echo "<option value=\"大きな揺らぎ（>数μm）のその場観察\">大きな揺らぎ（>数μm）のその場観察</option>";
                        break;
                      case "結晶":
                        echo "<option value=\"結晶格子の構造決定\">結晶格子の構造決定</option>";
                        echo "<option value=\"結晶サイズ\">結晶サイズ</option>";
                        echo "<option value=\"長周期（ラメラ晶と非晶相の周期）\">長周期（ラメラ晶と非晶相の周期）</option>";
                        echo "<option value=\"結晶化度\">結晶化度</option>";
                        echo "<option value=\"結晶モルフォロジー\">結晶モルフォロジー</option>";
                        echo "<option value=\"結晶中の分子コンホメーションとパッキング\">結晶中の分子コンホメーションとパッキング</option>";
                        echo "<option value=\"結晶化プロセス\">結晶化プロセス</option>";
                        break;
                      case "非晶固体":
                        echo "<option value=\"非晶質の短距離構造、分子間配置\">非晶質の短距離構造、分子間配置</option>";
                        echo "<option value=\"μm程度の密度揺らぎ\">μm程度の密度揺らぎ</option>";
                        echo "<option value=\"繊維、配向フィルムの構造、配向度\">繊維、配向フィルムの構造、配向度</option>";
                        break;
                      case "複雑系":
                        echo "<option value=\"液晶の相転移\">液晶の相転移</option>";
                        echo "<option value=\"液晶のモルフォロジー\">液晶のモルフォロジー</option>";
                        echo "<option value=\"スメチック液晶の層間距離\">スメチック液晶の層間距離</option>";
                        echo "<option value=\"液晶のメソゲン間配置\">液晶のメソゲン間配置</option>";
                        echo "<option value=\"球晶やミクロ相分離構造のモルフォロジー\">球晶やミクロ相分離構造のモルフォロジー</option>";
                        echo "<option value=\"ポリマーブレンドの相溶性とミクロ相分離\">ポリマーブレンドの相溶性とミクロ相分離</option>";
                        echo "<option value=\"孤立ミセル（分子集合体）のサイズと形状\">孤立ミセル（分子集合体）のサイズと形状</option>";
                        echo "<option value=\"ミセルの拡散係数から求めたサイズ\">ミセルの拡散係数から求めたサイズ</option>";
                        echo "<option value=\"ミセルが作る格子\">ミセルが作る格子</option>";
                        echo "<option value=\"分散系（エマルション）のサイズと形状\">分散系（エマルション）のサイズと形状</option>";
                        echo "<option value=\"ゲルの架橋点の構造\">ゲルの架橋点の構造</option>";
                        echo "<option value=\"ゲルの架橋点間距離\">ゲルの架橋点間距離</option>";
                        echo "<option value=\"ゲルの相分離プロセス\">ゲルの相分離プロセス</option>";
                        break;
                      case "表面・界面":
                        echo "<option value=\"表面化学組成\">表面化学組成</option>";
                        echo "<option value=\"表面厚、表面荒さ、表面構造\">表面厚、表面荒さ、表面構造</option>";
                        echo "<option value=\"界面構造\">界面構造</option>";
                        echo "<option value=\"自由液面での膜構造\">自由液面での膜構造</option>";
                        break;
                      // マクロ物性と分子物性の知りたい情報と測定法
                      case "全体を通して（マクロ物性）":
                        echo "<option value=\"基本的物理量（質量、長さ、厚さ、体積、密度、濃度・副井、温度、圧力など）\">基本的物理量（質量、長さ、厚さ、体積、密度、濃度・副井、温度、圧力など）</option>";
                      case "気体（マクロ物性）":
                        echo "<option value=\"圧縮率\">圧縮率</option>";
                        echo "<option value=\"粘性率、乱流\">粘性率、乱流</option>";
                        echo "<option value=\"誘電率、電気容量\">誘電率、電気容量</option>";
                        echo "<option value=\"屈折率、発色、吸収\">屈折率、発色、吸収</option>";
                        break;
                      case "液体、溶液（マクロ物性）":
                        echo "<option value=\"圧縮率\">圧縮率</option>";
                        echo "<option value=\"粘性率、乱流、粘弾性、変形と流動\">粘性率、乱流、粘弾性、変形と流動</option>";
                        echo "<option value=\"高分子鎖の希薄溶液中の粘弾性\">高分子鎖の希薄溶液中の粘弾性</option>";
                        echo "<option value=\"高分子鎖の拡散係数・分子運動\">高分子鎖の拡散係数・分子運動</option>";
                        echo "<option value=\"コンホメーション変化の速度\">コンホメーション変化の速度</option>";
                        echo "<option value=\"熱容量、一次相転移の潜熱\">熱容量、一次相転移の潜熱</option>";
                        echo "<option value=\"混合熱、反応熱\">混合熱、反応熱</option>";
                        echo "<option value=\"熱分解温度\">熱分解温度</option>";
                        echo "<option value=\"誘電率、誘電緩和\">誘電率、誘電緩和</option>";
                        echo "<option value=\"導電性、磁化率\">導電性、磁化率</option>";
                        echo "<option value=\"屈折率、複屈折、旋光性\">屈折率、複屈折、旋光性</option>";
                        echo "<option value=\"着色、発光、蛍光\">着色、発光、蛍光</option>";
                        break;
                      case "固体（マクロ物性）":
                        echo "<option value=\"弾性率、粘弾性挙動、変形下での応力・ひずみ関係\">弾性率、粘弾性挙動、変形下での応力・ひずみ関係</option>";
                        echo "<option value=\"強度（破断応力、破断ひずみ）\">強度（破断応力、破断ひずみ）</option>";
                        echo "<option value=\"単一分子鎖の力学物性、ナノ加工\">単一分子鎖の力学物性、ナノ加工</option>";
                        echo "<option value=\"熱容量、融解熱、結晶化熱\">熱容量、融解熱、結晶化熱</option>";
                        echo "<option value=\"融点、結晶化温度、ガラス転移温度\">融点、結晶化温度、ガラス転移温度</option>";
                        echo "<option value=\"熱伝導率\">熱伝導率</option>";
                        echo "<option value=\"耐熱性（熱分解温度）\">耐熱性（熱分解温度）</option>";
                        echo "<option value=\"誘電率、誘電緩和\">誘電率、誘電緩和</option>";
                        echo "<option value=\"導電性、光導電性、電界発光\">導電性、光導電性、電界発光</option>";
                        echo "<option value=\"絶縁破壊、磁化率\">絶縁破壊、磁化率</option>";
                        echo "<option value=\"屈折率、透明度（吸収、散乱）\">屈折率、透明度（吸収、散乱）</option>";
                        echo "<option value=\"複屈折、光弾性\">複屈折、光弾性</option>";
                        echo "<option value=\"第二高調波発生、非線形光学効果\">第二高調波発生、非線形光学効果</option>";
                      case "複雑系（マクロ物性）":
                        echo "<option value=\"多相系の相図\">多相系の相図</option>";
                        echo "<option value=\"コロイド・分散系のレオロジーと分子運動\">コロイド・分散系のレオロジーと分子運動</option>";
                        echo "<option value=\"液晶の相転移点\">液晶の相転移点</option>";
                        echo "<option value=\"液晶の分子配向による異方性\">液晶の分子配向による異方性</option>";
                        echo "<option value=\"ゲルの相転移点とゲル化プロセス\">ゲルの相転移点とゲル化プロセス</option>";
                        echo "<option value=\"ゲルの膨潤度\">ゲルの膨潤度</option>";
                        break;
                      case "表面・界面・膜（マクロ物性）":
                        echo "<option value=\"表面張力\">表面張力</option>";
                        echo "<option value=\"接触角\">接触角</option>";
                        echo "<option value=\"単分子展開膜の表面圧-表面積関係\">単分子展開膜の表面圧-表面積関係</option>";
                        echo "<option value=\"膜の弾性率と強度\">膜の弾性率と強度</option>";
                        echo "<option value=\"膜の分子透過性\">膜の分子透過性</option>";
                        echo "<option value=\"膜・界面の接着性\">膜・界面の接着性</option>";
                        break;
                      default:
                    }
                  }
                ?>
              </select>
            </td>
          </tr>
        <tbody>
      </table>
      <!--<input name="searchType" type="submit" value="AND検索">-->
      <!--<input name="searchType" type="submit" value="OR検索">-->
    </form>
    
<!--検索での表の結果表示部分-->
<?php
//error_reporting(0); // サイトを公開するときだけこれを入れる。warning取りきれていない場合。
if (isset($_POST['institute']) && isset($_POST['key']) || isset($_POST['inform'])){
  
  if (isset($_POST['institute']) && isset($_POST['key'])){
    if ($_POST['institute']!="-" && $_POST['key']!=""){
      $keywords_key = htmlspecialchars($_POST['institute'], ENT_QUOTES, "UTF-8").",".htmlspecialchars($_POST['key'], ENT_QUOTES, "UTF-8");
    }elseif ($_POST['institute']!="-"){
      $keywords_key = htmlspecialchars($_POST['institute'], ENT_QUOTES, "UTF-8");
    }else{
      $keywords_key = htmlspecialchars($_POST['key'], ENT_QUOTES, "UTF-8");
    }
  }
  
  $searchType_inform1="";
  if (isset($_POST['inform'])){
    $object1 = htmlspecialchars($_POST['object']);
    $inform1 = htmlspecialchars($_POST['inform']);
    $object_inform1 = $object1."：".$inform1;
    switch($object_inform1){
      //分子構造の知りたい情報と測定法
      case "有機化合物：単一物質かどうか（分離と精製）":
        $keywords_cat = "TLC, 薄層クロマトグラフィー, カラムクロマト, LC, 液体クロマト, GC, ガスクロ";
        $priority_cat = "  1,                      1,              1,  1,            1,  1,        1";
        break;
      case "有機化合物：元素組成":
        $keywords_cat = "XRF, 蛍光X線分析, 元素分析, MS, 質量分析";
        $priority_cat = "  1,            1,        1,  2,        2";
        break;
      case "有機化合物：分子量":
        $keywords_cat = "質量分析";
        $priority_cat = "       1";
        break;
      case "有機化合物：化学構造（原子のつながり方）":
        $keywords_cat = "NMR, 核磁気共鳴吸収, IR, 赤外吸収スペクトル";
        $priority_cat = "  1,              1,  2,                  2";
        break;
      case "有機化合物：化学構造（官能基、二重結合、芳香環など）":
        $keywords_cat = "IR, 赤外吸収スペクトル, UV, Vis, UV-Vis, 紫外可視吸収スペクトル";
        $priority_cat = " 1,                  1,  2,   2,      2,                      1";
        break;
      case "有機化合物：結晶構造、原子の位置":
        $keywords_cat = "単結晶X線構造解析, 単結晶X線回折";
        $priority_cat = "                1,             1";
        break;
      case "有機化合物：光学活性":
        $keywords_cat = "円二色性, 旋光性, 旋光分散";
        $priority_cat = "       1,      1,        1";
        break;
      //
      case "高分子化合物：分子量":
        $keywords_cat = "MS, 質量分析, GPC, ゲル透過クロマトグラフィー, 光散乱, 粘度測定";
        $priority_cat = " 1,        1,   2,                          2,      3,        4";
        break;
      case "高分子化合物：その他の基本化学構造":
        $keywords_cat = "NMR, 核磁気共鳴吸収, IR, 赤外吸収スペクトル, UV, Vis, UV-Vis, 紫外可視吸収スペクトル";
        $priority_cat = "  1,              1,  2,                  2,  3,   3,      3,                      3";
        break;
      case "高分子化合物：分子の形状、コンホメーション":
        $keywords_cat = "光散乱, 円二色性, 蛍光";
        $priority_cat = "     1,       2,     3";
        break;
      case "高分子化合物：単一分子のコンホメーション":
        $keywords_cat = "AFM, 原子間力顕微鏡, 蛍光顕微鏡";
        $priority_cat = "  1,              1,          2";
        break;
      case "高分子化合物：結晶格子中の構造":
        $keywords_cat = "単結晶X線構造解析, 単結晶X線回折";
        $priority_cat = "                1,             2";
        break;
      //
      case "錯体・有機金属化合物：結晶構造、原子の位置":
        $keywords_cat = "単結晶X線構造解析, 単結晶X線回折";
        $priority_cat = "                1,             2";
        break;
      case "錯体・有機金属化合物：その他の基本化学構造":
        $keywords_cat = "XRF, 蛍光X線分析,  元素分析, MS, 質量分析, NMR, 核磁気共鳴吸収";
        $priority_cat = "  1,           1,         1,  2,        2,   3,              3";
        break;
      case "錯体・有機金属化合物：電子状態":
        $keywords_cat = "UV, Vis, UV-Vis, 紫外可視吸収スペクトル, CV, サイクリックボルタンメトリー, ESR, 電子スピン共鳴分光, XPS, ESCA, 光電子分光, UPS";
        $priority_cat = " 1,   1,      1,                      1,  2,                            2,   3,                  3,   4,    4,          4,   5";
        break;
      //
      case "分子の電子構造：色、電子状態":
        $keywords_cat = "UV, Vis, UV-Vis, 紫外可視吸収スペクトル, UPS, XPS, ESCA, 光電子分光";
        $priority_cat = " 1,   1,      1,                      1,   2,   2,    2,          2";
        break;
      case "分子の電子構造：反応中間体":
        $keywords_cat = "過渡吸収, ESR, 電子スピン共鳴分光";
        $priority_cat = "       1,   2,                  2";
        break;
      case "分子の電子構造：光励起状態":
        $keywords_cat = "蛍光, 発光寿命, 過渡吸収";
        $priority_cat = "   1,        2,        2";
        break;
      case "分子の電子構造：電荷移動、酸化還元状態":
        $keywords_cat = "UV, Vis, UV-Vis, 紫外可視吸収スペクトル, ESR, 電子スピン共鳴分光, XPS, ESCA, 光電子分光, UPS";
        $priority_cat = " 1,   1,      1,                      1,   2,                  2,   3,    3,          3,   4";
        break;
      case "分子の電子構造：単一分子分光":
        $keywords_cat = "蛍光";
        $priority_cat = "   1";
        break;
      //
      // 高次構造の知りたい情報と測定法
      case "液体・溶液：最近接・第2近接の分子間距離":
        $keywords_cat = "XRD, 広角X線散乱, 広角中性子散乱, 中性子散乱";
        $priority_cat = "  1,           1,              2,          2";
        break;
      case "液体・溶液：分子間相互作用（水素結合、電荷移動相互作用）、分子間配置":
        $keywords_cat = "NMR, 核磁気共鳴吸収, IR, 赤外吸収スペクトル, 蛍光";
        $priority_cat = "  1,              1,  2,                  2,    3";
        break;
      case "液体・溶液：クラスター、会合体の構造":
        $keywords_cat = "SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱, 光散乱";
        $priority_cat = "   1,        1,           1,              2,    3";
        break;
      case "液体・溶液：クラスター、会合体の拡散係数から求めたサイズ":
        $keywords_cat = "動的光散乱";
        $priority_cat = "         1";
        break;
      case "高分子鎖の絡み合い網目のサイズ（相関長）":
        $keywords_cat = "SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱";
        $priority_cat = "   1,        1,           1,              2";
        break;
      case "希薄溶液中の孤立高分子鎖のサイズ":
        $keywords_cat = "光散乱";
        $priority_cat = "     1";
        break;
      case "ラテックス粒子の結晶格子":
        $keywords_cat = "光散乱";
        $priority_cat = "     1";
        break;
      case "大きな揺らぎ（>数μm）のその場観察":
        $keywords_cat = "光学顕微鏡";
        $priority_cat = "     1";
        break;
      //
      case "結晶：結晶格子の構造決定":
        $keywords_cat = "単結晶X線構造解析, 単結晶X線回折";
        $priority_cat = "                1,             1";
        break;
      case "結晶：結晶サイズ":
        $keywords_cat = "XRD, 広角X線散乱, 中性子散乱";
        $priority_cat = "  1,           1,          2";
        break;
      case "結晶：長周期（ラメラ晶と非晶相の周期）":
        $keywords_cat = "SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱";
        $priority_cat = "   1,         1,          1,              2";
        break;
      case "結晶：結晶化度":
        $keywords_cat = "DSC, 示差走査熱量測定, XRD, 広角X線散乱, 広角中性子散乱, 中性子散乱, 密度測定";
        $priority_cat = "   1,               1,   2,           2,              3,          3,        4";
        break;
      case "結晶：結晶モルフォロジー":
        $keywords_cat = "SEM, 電子顕微鏡, TEM,  光学顕微鏡, SPM, 走査プローブ顕微鏡, AFM";
        $priority_cat = "  1,          1,   2,           3,   4,                  4,   4";
        break;
      case "結晶：結晶中の分子コンホメーションとパッキング":
        $keywords_cat = "IR, 赤外吸収スペクトル, 重水素化ラベル中性子散乱";
        $priority_cat = " 1,                  1,                        2";
        break;
      case "結晶：結晶化プロセス":
        $keywords_cat = "DSC, 示差走査熱量測定, FT-IR, SORX線, 放射光X線, 偏光顕微鏡, 光散乱";
        $priority_cat = "  1,                1,     2,      3,         3,          4,      4";
        break;
      //
      case "非晶固体：非晶質の短距離構造、分子間配置":
        $keywords_cat = "XRD, 広角X線散乱, 広角中性子散乱, 中性子散乱, 固体NMR, 蛍光";
        $priority_cat = "  1,           1,              2,          2,       3,    4";
        break;
      case "非晶固体：μm程度の密度揺らぎ":
        $keywords_cat = "光散乱";
        $priority_cat = "     1";
        break;
      case "非晶固体：繊維、配向フィルムの構造、配向度":
        $keywords_cat = "XRD, 広角X線散乱, 広角中性子散乱, 中性子散乱, SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱, 偏光赤外二色性, 偏光顕微鏡, 複屈折測定";
        $priority_cat = "  1,           1,              1,          2,    3,        3,           3,              4,              5,          6,          7";
        break;
      //
      case "複雑系：液晶の相転移":
        $keywords_cat = "偏光顕微鏡, DSC, 示差走査熱量測定";
        $priority_cat = "         1,   2,                2";
        break;
      case "複雑系：液晶のモルフォロジー":
        $keywords_cat = "偏光顕微鏡";
        $priority_cat = "         1";
        break;
      case "複雑系：スメチック液晶の層間距離":
        $keywords_cat = "XRD, 広角X線散乱, 広角中性子散乱, 中性子散乱, SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱";
        $priority_cat = "  1,           1,              2,          2,    3,        3,           3,              4";
        break;
      case "複雑系：液晶のメソゲン間配置":
        $keywords_cat = "蛍光, NMR, 核磁気共鳴吸収";
        $priority_cat = "   1,   2,              2";
        break;
      case "複雑系：球晶やミクロ相分離構造のモルフォロジー":
        $keywords_cat = "電子顕微鏡, 光学顕微鏡, 走査プローブ顕微鏡, SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱, 光散乱";
        $priority_cat = "         1,          2,                  3,    4,        4,           4,              5,      6";
        break;
      case "複雑系：ポリマーブレンドの相溶性とミクロ相分離":
        $keywords_cat = "DSC, 示差走査熱量測定, 濁度測定, 蛍光, 光学顕微鏡";
        $priority_cat = "  1,                 1,        2,   3,          4";
        break;
      case "複雑系：孤立ミセル（分子集合体）のサイズと形状":
        $keywords_cat = "SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱, 光散乱";
        $priority_cat = "   1,        1,           1,              2,      3";
        break;
      case "複雑系：ミセルの拡散係数から求めたサイズ":
        $keywords_cat = "動的光散乱";
        $priority_cat = "         1";
        break;
      case "複雑系：ミセルが作る格子":
        $keywords_cat = "SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱";
        $priority_cat = "   1,        1,           1,              2";
        break;
      case "複雑系：分散系（エマルション）のサイズと形状":
        $keywords_cat = "光散乱";
        $priority_cat = "     1";
        break;
      case "複雑系：ゲルの架橋点の構造":
        $keywords_cat = "NMR, 核磁気共鳴吸収, XRD, 広角X線散乱, 広角中性子散乱, 中性子散乱";
        $priority_cat = "  1,              1,   2,           2,              3,          3";
        break;
      case "複雑系：ゲルの架橋点間距離":
        $keywords_cat = "動的光散乱, SAXS, 小角散乱, 小角X線散乱, 小角中性子散乱";
        $priority_cat = "         1,    2,        2,           2,              3";
        break;
      case "複雑系：ゲルの相分離プロセス":
        $keywords_cat = "光散乱";
        $priority_cat = "     1";
        break;
      //
      case "表面・界面：表面化学組成":
        $keywords_cat = "UPS, XPS, ESCA, 光電子分光, 全反射IR, 全反射赤外吸収スペクトル";
        $priority_cat = "  1,   2,    2,          2,        3,                        3";
        break;
      case "表面・界面：表面厚、表面荒さ、表面構造":
        $keywords_cat = "XRR, 反射率測定, エリプソメトリー, 電子顕微鏡, 光学顕微鏡, 走査プローブ顕微鏡";
        $priority_cat = "  1,          1,                2,          3,          4,                  5";
        break;
      case "表面・界面：自由液面での膜構造":
        $keywords_cat = "エリプソメトリー, XRR, 反射率測定, X線反射率測定";
        $priority_cat = "               1,   2,          2,             2";
        break;
      //
      //マクロ物性と分子物性の知りたい情報と測定法
      case "全体を通して（マクロ物性）：基本的物理量（質量、長さ、厚さ、体積、密度、濃度・副井、温度、圧力など）":
        $keywords_cat = "";
        $priority_cat = "";
        break;
      //
      case "気体（マクロ物性）：圧縮率":
        $keywords_cat = "PVT測定, 音速";
        $priority_cat = "      1,    2";
        break;
      case "気体（マクロ物性）：粘性率、乱流":
        $keywords_cat = "流体力学測定";
        $priority_cat = "           1";
        break;
      case "気体（マクロ物性）：誘電率、電気容量":
        $keywords_cat = "誘電率測定";
        $priority_cat = "         1";
        break;
      case "気体（マクロ物性）：屈折率、発色、吸収":
        $keywords_cat = "光物性, 吸収スペクトル, 光散乱";
        $priority_cat = "     1,              2,      3";
        break;
      //
      case "液体、溶液（マクロ物性）：圧縮率":
        $keywords_cat = "PVT測定, 音速";
        $priority_cat = "      1,    2";
        break;
      case "液体、溶液（マクロ物性）：粘性率、乱流、粘弾性、変形と流動":
        $keywords_cat = "レオロジー測定";
        $priority_cat = "             1";
        break;
      case "液体、溶液（マクロ物性）：高分子鎖の希薄溶液中の粘弾性":
        $keywords_cat = "レオロジー測定";
        $priority_cat = "             1";
        break;
      case "液体、溶液（マクロ物性）：高分子鎖の拡散係数・分子運動":
        $keywords_cat = "動的光散乱, 準弾性中性子散乱, NMR, 核磁気共鳴吸収, 蛍光測定, りん光測定, リン光測定, 燐光測定";
        $priority_cat = "         1,                2,   3,              ,         4,          4,          4,        4";
        break;
      case "液体、溶液（マクロ物性）：コンホメーション変化の速度":
        $keywords_cat = "蛍光測定, 三重項測定, 誘電緩和";
        $priority_cat = "       1,         2,         3";
        break;
      case "液体、溶液（マクロ物性）：熱容量、一次相転移の潜熱":
        $keywords_cat = "DSC, 示差走査熱量測定";
        $priority_cat = "  1,                1";
        break;
      case "液体、溶液（マクロ物性）：混合熱、反応熱":
        $keywords_cat = "双子型熱量計, DSC, 示差走査熱量測定";
        $priority_cat = "           1,   2,                2";
        break;
      case "液体、溶液（マクロ物性）：熱分解温度":
        $keywords_cat = "熱量計, DSC, 示差走査熱量測定";
        $priority_cat = "     1,   2,                2";
        break;
      case "液体、溶液（マクロ物性）：誘電率、誘電緩和":
        $keywords_cat = "誘電緩和測定";
        $priority_cat = "           1";
        break;
      case "液体、溶液（マクロ物性）：導電性、磁化率":
        $keywords_cat = "";
        $priority_cat = "";
        break;
      case "液体、溶液（マクロ物性）：屈折率、複屈折、旋光性":
        $keywords_cat = "屈折率, 屈折率測定, 複屈折率, 複屈折率測定, 旋光度, 旋光度測定";
        $priority_cat = "     1,          1,        2,            2,      3,          4";
        break;
      case "液体、溶液（マクロ物性）：着色、発光、蛍光":
        $keywords_cat = "吸収スペクトル, 発光スペクトル";
        $priority_cat = "             1,              2";
        break;
      //
      case "固体（マクロ物性）：弾性率、粘弾性挙動、変形下での応力・ひずみ関係":
        $keywords_cat = "固体力学, レオロジー測定";
        $priority_cat = "       1,              2";
        break;
      case "固体（マクロ物性）：強度（破断応力、破断ひずみ）":
        $keywords_cat = "固体力学, レオロジー測定";
        $priority_cat = "       1,              2";
        break;
      case "固体（マクロ物性）：単一分子鎖の力学物性、ナノ加工":
        $keywords_cat = "AFM, 原子間力顕微鏡";
        $priority_cat = "  1,              1";
        break;
      case "固体（マクロ物性）：熱容量、融解熱、結晶化熱":
        $keywords_cat = "DSC, 示差走査熱量測定";
        $priority_cat = "  1,                1";
        break;
      case "固体（マクロ物性）：融点、結晶化温度、ガラス転移温度":
        $keywords_cat = "DSC, 示差走査熱量測定, DTA, TG-DTA, 示差熱分析";
        $priority_cat = "  1,                1,   2,      2,          2";
        break;
      case "固体（マクロ物性）：熱伝導率":
        $keywords_cat = "LF, レーザーフラッシュ";
        $priority_cat = " 1,                  1";
        break;
      case "固体（マクロ物性）：耐熱性（熱分解温度）":
        $keywords_cat = "TG, TG-DTA, 熱重量分析, DSC";
        $priority_cat = " 1,      1,          1,   2";
        break;
      case "固体（マクロ物性）：誘電率、誘電緩和":
        $keywords_cat = "誘電緩和測定";
        $priority_cat = "           1";
        break;
      case "固体（マクロ物性）：絶縁破壊、磁化率":
        $keywords_cat = "";
        $priority_cat = "";
        break;
      case "固体（マクロ物性）：屈折率、透明度（吸収、散乱）":
        $keywords_cat = "屈折率, 屈折率測定, 吸収測定";
        $priority_cat = "     1,          1,        2";
        break;
      case "固体（マクロ物性）：複屈折、光弾性":
        $keywords_cat = "複屈折, 光弾性測定";
        $priority_cat = "     1,          2";
        break;
      case "固体（マクロ物性）：第二高調波発生、非線形光学効果":
        $keywords_cat = "非線形光学現象測定";
        $priority_cat = "                 1";
        break;
      //
      case "複雑系（マクロ物性）：多相系の相図":
        $keywords_cat = "共存曲線の測定";
        $priority_cat = "             1";
        break;
      case "複雑系（マクロ物性）：コロイド・分散系のレオロジーと分子運動":
        $keywords_cat = "レオロジー測定, 動的光散乱, NMR, 核磁気共鳴吸収, 蛍光測定";
        $priority_cat = "             1,          2,   3,              3,        4";
        break;
      case "複雑系（マクロ物性）：液晶の相転移点":
        $keywords_cat = "DSC, 示差走査熱量測定, 偏光顕微鏡";
        $priority_cat = "  1,                1,          2";
        break;
      case "複雑系（マクロ物性）：液晶の分子配向による異方性":
        $keywords_cat = "偏光顕微鏡";
        $priority_cat = "         1";
        break;
      case "複雑系（マクロ物性）：ゲルの相転移点とゲル化プロセス":
        $keywords_cat = "動的光散乱, 熱測定, 力学的性質測定";
        $priority_cat = "         1,      2,              3";
        break;
      case "複雑系（マクロ物性）：ゲルの膨潤度":
        $keywords_cat = "寸法測定";
        $priority_cat = "       1";
        break;
      //
      case "表面・界面・膜（マクロ物性）：表面張力":
        $keywords_cat = "懸滴法, 静泡法, 円環法, つり板法";
        $priority_cat = "     1,      2,      3,        4";
        break;
      case "表面・界面・膜（マクロ物性）：接触角":
        $keywords_cat = "";
        $priority_cat = "";
        break;
      case "表面・界面・膜（マクロ物性）：単分子展開膜の表面圧-表面積関係":
        $keywords_cat = "π-A曲線";
        $priority_cat = "       1";
        break;
      case "表面・界面・膜（マクロ物性）：膜の弾性率と強度":
        $keywords_cat = "固体力学測定, AFM, 原子間力顕微鏡";
        $priority_cat = "           1,   2,              3";
        break;
      case "表面・界面・膜（マクロ物性）：膜の分子透過性":
        $keywords_cat = "透過膜物性, 分離膜物性";
        $priority_cat = "         1,          2";
        break;
      case "表面・界面・膜（マクロ物性）：膜・界面の接着性":
        $keywords_cat = "";
        $priority_cat = "";
        break;
      default:
        $keywords_cat="";
    }
    if ($keywords_key!=""){
      $searchType_inform1 = "AND検索";
    }else{
      $searchType_inform1 = "OR検索";
    }
    $keywords = $keywords_cat;
  }
  
  $keyword01 = ltrim($keywords_key,",");
  $keyword02 = rtrim($keyword01,",");
  $keyword03 = ltrim($keyword02);
  $keyword04 = rtrim($keyword03);
  $keyword05 = ltrim($keyword04,"　");
  $keyword06 = rtrim($keyword05,"　");
  $keywords_key  = ltrim($keyword06 ,",");
  //
  $keyword1 = str_replace(array("　", " " , "、", "，", "?", "http", "\"", "\”"), ",", $keywords_key); 
  $keyword2 = preg_replace('|,+|', ',', $keyword1);
  $keyword3 = rtrim($keyword2, ",");
  $keyword  = explode(",", $keyword3);
  //
  if ($_POST['institute']!="" || $_POST['key']!="") {
    $found_key_const=sizeof($keyword);
  }else{
    $found_key_const=sizeof($keyword)-1;
  }
  
  //print $found_key_const;
  
  if (isset($_POST['key']) && isset($_POST['inform'])){
    if ($keywords_key!=""){
      $keywords = $keywords_key.",".$keywords_cat;
    }
  }else if (isset($_POST['key'])) {
    $keywords = $keywords_key;
  }
  
  if ($keywords_cat!="") {
    print "<br>（対象となる測定法： ".$keywords_cat."）<br><br>";
  }
  
  if ($keywords!=""){
    $keyword1 = str_replace(array("　", " " , "、", "，", "?", "http", "\"", "\”"), ",", $keywords); 
    $keyword2 = preg_replace('|,+|', ',', $keyword1);
    $keyword3 = rtrim($keyword2, ",");
    $keyword  = explode(",", $keyword3);
    //
    $priority_cat1 = str_replace(array("　", " " , "、", "，", "?", "http", "\"", "\”"), ",", $priority_cat); 
    $priority_cat2 = preg_replace('|,+|', ',', $priority_cat1);
    $priority_cat3 = rtrim($priority_cat2, ",");
    $priority_cat_char  = explode(",", $priority_cat3);
    
    if (sizeof($keyword)<=15 && mb_strlen($keywords)<=150 ){
      
      // csvファイルの読み込み
      $read_data=file("./rcs/data/新共用システム設備一覧表_UTF-8.csv");
      
      // csvファイルの読み込み、php 5.1 or later、テスト中(まだ成功していない）
      //$filepath = "./rcs/data/新共用システム設備一覧表.csv";
      //$read_data = new SplFileObject($filepath);
      //$read_data -> setFlags(SplFileObject::READ_CSV);
      
      // utf-8に変換と表のタイトル
      $data_convert = str_replace(array(","), "</td><td>", $read_data);
      $data = str_replace(array("\r\n","\r","\n"), "", $data_convert); // 今後の検索のために改行コード無しに変換
      foreach ($data as $lineno => $line) {
        $data[$lineno] = mb_convert_encoding($line, "UTF-8", "auto");
      }
      //print $found_key_const;
      //print sizeof($keyword);
      //print $keywords_key;
      //print intval($priority_cat_char[1]);
      //print sizeof($priority_cat_char);
      
      // ANDとOR検索
      if (isset($_POST["searchType"]) || $searchType_inform1!="") {
        if (isset($_POST["searchType"])){ 
          $aow = htmlspecialchars($_POST["searchType"], ENT_QUOTES, "UTF-8");
        }elseif ($searchType_inform1!=""){
          $aow = $searchType_inform1; 
        }
        $n=0;
        if($aow=="AND検索"){ $found_key_const_search=$found_key_const; }
        if($aow=="OR検索"){ $found_key_const_search=1; }
        for($i=1;$i<sizeof($data);$i++){
          $lines=strip_tags($data[$i]);
          $found_key=0;
          $found_cat=0;
          $priority_cat_num=0;
          for($j=0;$j<$found_key_const;$j++){
            if(mb_eregi($keyword[$j], $lines) && $aow=="AND検索"){
              $found_key++;
              // 特殊処理
              if(mb_eregi("グロー放電発光表面分析装置", $lines) && $keyword[$j]=="XPS"){
                $found_key--;
              }
              if(mb_eregi("共焦点ﾚｰｻﾞｰ顕微鏡", $lines) && $keyword[$j]=="IR"){
                $found_key--;
              }
              if(mb_eregi("顕微蛍光X線分析装置", $lines) && $keyword[$j]=="蛍光"){
                $found_key--;
              }
              //
            }
            if(mb_eregi($keyword[$j], $lines) && $aow=="OR検索"){
              $found_key=1;
            }
          }
          for($j=$found_key_const;$j<sizeof($keyword);$j++){
            if(mb_eregi($keyword[$j], $lines)){
              $found_cat=1;
              $priority_cat_num=intval($priority_cat_char[$j-$found_key_const+1]);
              // 特殊処理
              if(mb_eregi("グロー放電発光表面分析装置", $lines) && $keyword[$j]=="XPS"){
                $found_cat=0;
              }
              if(mb_eregi("共焦点ﾚｰｻﾞｰ顕微鏡", $lines) && $keyword[$j]=="IR"){
                $found_cat=0;
              }
              if(mb_eregi("顕微蛍光X線分析装置", $lines) && $keyword[$j]=="蛍光"){
                $found_cat=0;
              }
              if(mb_eregi("顕微蛍光X線分析装置", $lines) && $keyword[$j]=="蛍光X線分析"){
                $found_cat=1;
              }
              //
            }
          }
          if ($keywords_cat!="" && $aow=="OR検索"){
            if ($found_key==$found_key_const_search || $found_cat==1){
              $showdata[$n]=$i;
              $showdata_pri[$n]=$priority_cat_num;
              $n++;
            }
          }else if($keywords_cat!=""){
            if ($found_key==$found_key_const_search && $found_cat==1){
              $showdata[$n]=$i;
              $showdata_pri[$n]=$priority_cat_num;
              $n++;
            }
          }else if($found_key==$found_key_const_search){
            $showdata[$n]=$i;
            $n++;
          }
        }
        if($aow=="AND検索"){ echo "ANDの検索結果  "; }
        if($aow=="OR検索") { echo "ORの検索結果  "; }
        echo "<font size=\"5\" color=rgb(255,0,0)>", $n, " 件 </font>";
        //
        // ANDとORの結果の表示（ANDとORで共通）
        echo "※設備名をクリックすると詳細情報が表示されます<br></br>";
        
        // タイトルの部分
        foreach ($data as $lineno => $line) {
          if(mb_eregi("設備名", $data[$lineno])){
            echo "<table border=\"1\" width=\"100%\" style=\"table-layout: fixed;\">";
            $data[$lineno] = str_replace(array("</td><td>"), "</th><th>", $data[$lineno]); 
            $list = explode("</th><th>", $data[$lineno]);
            
            // リンクを貼るためにRCS, No, 設備名, 検索キーの場所を探して、$line_rcsno, $line_no, $line_linkno, $line_keynoに入れる
            //初期化
            $line_rcsno      = "999";
            $line_no         = "999";
            $line_keyno      = "999";
            $line_link_keyno = "999";
            foreach ($list as $lineno_tag => $line_tag) {
              if($line_tag == "RCS"){
                $line_rcsno  = $lineno_tag;
              }
              if($line_tag == "No."){
                $line_no     = $lineno_tag;
              }
              if($line_tag == "設備名"){
                $line_linkno = $lineno_tag;
              }
              if($line_tag == "検索キー"){
                $line_keyno  = $lineno_tag;
              }
              if($line_tag == "リンクキー"){
                $line_link_keyno  = $lineno_tag;
              }
            }
            
            // タイトル表示
            echo "<tr bgcolor=rgb(187,255,152)>";
            foreach ($list as $lineno_title => $line_title) {
              if($lineno_title == $line_keyno or $lineno_title == $line_link_keyno){
                //検索キーの欄で、表示しないことにしている。
              }else{
                echo "<th>$line_title</th>";
              }
            }
            echo "</tr>";
          }
        }
        
        // 主要な表の部分
        //初期化
        $rcsno = "9999";
        $no    = "100";
        $link  = "RCSXNoYZ";
        //
        $priority_cat_max = 1;
        for($m=1;$m<sizeof($priority_cat_char);$m++){
          if (intval($priority_cat_char[$m]) > $priority_cat_max){
            $priority_cat_max = intval($priority_cat_char[$m]);
          }
        }
        //print $priority_cat_max;
        //
        for($k=1;$k<=$priority_cat_max;$k++){
          for($i=0;$i<$n;$i++){
            if($showdata_pri[$i]==$k){
              $j=$showdata[$i];
              $list = explode("</td><td>", $data[$j]);
              if($line_rcsno != "999"){
                $rcsno = $list[$line_rcsno];
              }
              if($line_no != "999"){
                $no    = $list[$line_no];
                if (intval($no) <= 9){
                  $no = "0".$list[$line_no];
                }
              }
              if($line_link_keyno != "999"){
                $link = $list[$line_link_keyno];
              }
              echo "<tr width=1100, bgcolor=rgb(242,255,226)>";
              foreach ($list as $lineno_main => $line_main) {
                if($lineno_main == $line_linkno){
                  // RCSとNo.でリンク。
                  if($rcsno != "9999" and $no != "100"){
                    $link = "RCS".$rcsno."No".$no;
                  }
                  if( $link != "RCSXNoYZ" ){
                    echo "<td><a href=\"./rcs/contents/{$link}.html\" target=\"_blank\">$line_main</a></td>";
                  }else{
                    echo "<td>$line_main</td>";
                  }
                  // 設備名でリンク。文字コードの種類に注意。同じ設備名では不良動作するため廃止
                  //$line_main_correct = str_replace(array("/"), "", $line_main);
                  //echo "<td><a href=\"./rcs/contents/{$line_main_correct}.html\" target=\"_blank\">$line_main</a></td>";
                }elseif($lineno_main == $line_keyno or $lineno_main == $line_link_keyno){
                  //検索キーやリンクの欄で表示しないことにしている。
                }else{
                  echo "<td>$line_main</td>";
                }
              }
              echo "</tr>"; 
            }
          }
        }
      }
    }elseif(sizeof($keyword)>15 && mb_strlen($keywords)>150){
      echo "お手数をおかけしますが、サーバーの負担軽減のために<br>ワード数は15個以内、フリーワードは150文字以内に制限させて頂いております<br></br>";
    }elseif(sizeof($keyword)>15){
      echo "お手数をおかけしますが、サーバーの負担軽減のために<br>ワード数は15個以内に制限させて頂いております<br></br>";
    }elseif(mb_strlen($keywords)>150){
      echo "お手数をおかけしますが、サーバーの負担軽減のために<br>フリーワードは150文字以内に制限させて頂いております<br></br>";
    }
  }
}
?>
    
    </table>
  </body>
</html>
