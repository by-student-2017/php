<?php
  // カレンダーの年月をタイムスタンプを使って指定
  date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
  if (isset($_GET["date"]) && $_GET["date"] != "") {
    $date_timestamp = $_GET["date"];
  } else {
    $date_timestamp = time();
  }
  $month = date("m", $date_timestamp);
  $year = date("Y", $date_timestamp);
  //$hour = date("G", time());
  //$minute = date("i", time());
  
  $first_date = mktime(0, 0, 0, $month, 1, $year);
  $last_date = mktime(0, 0, 0, $month + 1, 0, $year);
  
  // 最初の日と最後の日の｢日にち」の部分だけ数字で取り出す
  $first_day = date("j", $first_date);
  $last_day = date("j", $last_date);
  
  // 全ての日の曜日を得る。
  for($day = $first_day; $day <= $last_day; $day++) {
    $day_timestamp = mktime(0, 0, 0, $month, $day, $year); 
    $week[$day] = date("w", $day_timestamp); 
  }
?>

<!DOCTYPE html>
<html xml:lang="ja">
<head>
  <title>カレンダー（設備・共用装置予約システム）</title>
  <style type="text/css">
    a:link {color: #3366FF; background-color: transparent;  text-decoration: none; font-weight: bold;}
    a:visited {color: #2B318F; background-color: transparent;   text-decoration: none; font-weight: bold;}
    a:hover {color: #00BFFF; background-color: transparent;  text-decoration: underline;}
    body {color: #333333; background-color: #FFFFFF;}
    table {border: 1px solid #CCCCCC; border-collapse: collapse;  margin-bottom: 1em;}
    td {border: 1px solid #CCCCCC; width: 1.0em; height: 1.0em;  text-align: right; vertical-align: bottom; padding: 2px;}
    th {border: 1px solid #CCCCCC; color: #333333;  background-color: #F0F0F0; padding: 5px;}
    div.blocka{
      float: left;
      width: 215px;
    }
    div.blockc{
      clear: both;
    }
    h1   {color: #666666; font-size: 1.3em; font-weight: bold;  border-left: 10px solid #99CC99; border-bottom: 2px solid #99CC99;}
  </style>
</head>
<body>
<?php
  date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
  echo "<h1>名古屋○○大学　設備・装置共用予約システム<br>カレンダー",date("　［現在時刻： Y年m月j日　H時i分］（最新の情報に更新で時刻が更新）") ,"</h1>";
?>
<div class="blocka">
  <table border="1">
    <tr>
      <th colspan="2"><a href="schedule_calendar_all.php?date= <?php print(strtotime("-1 month", $first_date)); ?>">前月</a></th>
      <th colspan="3"><?php print(date("Y", $date_timestamp) . "年" . date("n", $date_timestamp) . "月"); ?></th>
      <th colspan="2"><a href="schedule_calendar_all.php?date= <?php print(strtotime("+1 month", $first_date)); ?>">次月</a></th>
    </tr>
    <tr>
      <th>日</th>
      <th>月</th>
      <th>火</th>
      <th>水</th>
      <th>木</th>
      <th>金</th>
      <th>土</th>
    </tr>
    <tr>
      <?php
        // カレンダーの最初の空白部分
        for ($i = 0; $i < $week[$first_day]; $i++) {
          print("<td></td>\n");
        }
        
        // スケジュールにリンクをつける。URLに情報が記載。$_GET["xxx"]でデータが取得できる
        for ($day = $first_day; $day <= $last_day; $day++) {
          if ($week[$day] == 0) {
            print("</tr>\n<tr>\n");
          }
          $day_timestamp = mktime(0, 0, 0, $month, $day, $year); 
          print("<td><a href=\"schedule_calendar_all.php?date=".$day_timestamp."\">$day</a></td>\n");
          //print("<td><a href=\"schedule_calendar_all.php?year=".$year."&month=".$month."&day=".$day\">$day</a></td>\n");
        }
        
        // カレンダーの最後の空白部分
        for ($i = $week[$last_day] + 1; $i < 7; $i++) {
          print ("<td></td>\n");
        }
      ?>
    </tr>
  </table>
</div>
<div class="blockb">
  <table border="1">
    <tr>
      <th colspan="1" width="250"><a href="schedule_calendar_all.php?date= <?php print(strtotime("-1 day",$date_timestamp)); ?>">前日</a></th>
      <th colspan="26" width="400"><?php print(date("Y", $date_timestamp) . "年" . date("n", $date_timestamp) . "月". date("j", $date_timestamp) . "日"); ?></th>
      <th colspan="1" width="160"><a href="schedule_calendar_all.php?date= <?php print(strtotime("+1 day",$date_timestamp)); ?>">次日</a></th>
    </tr>
    
    <td colspan="1"  width="250"></td>
    <td colspan="26" width="400">時刻</td>
    <td colspan="1"  width="160" ></td>
    
    <tr>
      <td>設備名</td>
      <td></td>
      <?php
        for($i=0;$i<24;$i++){
          echo "<td>$i</td>";
        }
      ?>
      <td></td>
      <td>研究室（使用者）</td>
    </tr>
    <?php
      date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
      // 日付の情報をURLから取得できるか調べ、可能なら取得する
      if (isset($_GET["year"])  and $_GET["year"]  !="" and
        isset($_GET["month"]) and $_GET["month"] !="" and
        isset($_GET["day"])   and $_GET["day"]   !=""){
        
        $year  = htmlspecialchars($_GET["year"], ENT_QUOTES);
        $month = htmlspecialchars($_GET["month"], ENT_QUOTES);
        $day   = htmlspecialchars($_GET["day"], ENT_QUOTES);
        $hrsminsec = date("H", $date_timestamp).date("i", $date_timestamp).date("s", $date_timestamp);
        
        $title = "　研究室";
        $start_hrs = date("G", $date_timestamp); 
        $start_min = date("i", $date_timestamp); 
        $end_hrs   = 17;
        $end_min   = 30;
        $time = 0;
        $body  = "";
        $total_time = 0;
      }else{
        // URLに情報が無い場合、登録画面の日付を本日に指定
        date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
        $hrsminsec = date("H", $date_timestamp).date("i", $date_timestamp).date("s", $date_timestamp);
        $day   = date("j", $date_timestamp); 
        $month = date("m", $date_timestamp); 
        $year  = date("Y", $date_timestamp);
        $hrsminsec = date("H", $date_timestamp).date("i", $date_timestamp).date("s", $date_timestamp);
        $title = "　研究室";
        $start_hrs = date("G", $date_timestamp);
        $start_min = date("i", $date_timestamp);
        $end_hrs   = 17;
        $end_min   = 30;
        $time = 0;
        $body  = "";
        $total_time = 0;
      }
      $day_timestamp = mktime(0, 0, 0, $month, $day, $year); 
      $data=file("./rcs/data/rcs_calendar.csv"); //改行コードをCR+LFで保存してください。
      foreach ($data as $lineno => $line) {
        if ($lineno > 0){
          list($name, $rcsno) = explode(",", $line);
          print("<tr bgcolor=rgb(242,255,226)><td><a target=\"_blank\" href=\"schedule_calendar.php?\$rcsno=$rcsno&\$name=$name&year=$year&month=$month&day=$day&date=$day_timestamp\">$name</a></td>\n");
          print("<td bgcolor=rgb(256,256,256) colspan=\"26\" width=\"400\">");
            // スケジュールの時間を棒グラフで書き込む
            // samplefile.txtからデータを取得]
            $new_rcsno = rtrim($rcsno, "\r\n");
            $filename = ".\\rcs\\text\\".$new_rcsno."_reservation.txt";
            $schedule_list = file($filename);
            // スケジュールが存在するかどうかチェックして棒グラフを書き込み
            $colono = 0;
            foreach ($schedule_list as $lineno2 => $line2) {
              list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $line2);
              if ($schedule_date == $year . $month . sprintf("%02d", $day)) {
                $start_hrs = intval(substr($start_time, 0, 2));
                $start_min = intval(substr($start_time, 2, 2));
                $end_hrs = intval(substr($end_time, 0, 2));
                $end_min = intval(substr($end_time, 2, 2));
                $start_time = ($start_hrs + $start_min/60)*20 +40; // 500で24時間, 約20px/1h
                $end_time   = ($end_hrs   + $end_min/60  )*20 +40 - $start_time;
                switch ($colono){
                case 0:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #32CD32; background-color: #32CD32;   width: ".$end_time."px; font-size: 11px; margin-left:".$start_time."px; margin-bottom:1px; \">&nbsp;</div>");
                  break;
                case 1:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #ffc0cb; background-color: #ffc0cb;   width: ".$end_time."px; font-size: 11px; margin-left:".$start_time."px; margin-bottom:1px; \">&nbsp;</div>");
                  break;
                case 2:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #87ceeb; background-color: #87ceeb;   width: ".$end_time."px; font-size: 11px; margin-left:".$start_time."px; margin-bottom:1px; \">&nbsp;</div>");
                  break;
                case 3:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #deb887; background-color: #deb887;   width: ".$end_time."px; font-size: 11px; margin-left:".$start_time."px; margin-bottom:1px; \">&nbsp;</div>");
                  break;
                default:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #32CD32; background-color: #32CD32;   width: ".$end_time."px; font-size: 11px; margin-left:".$start_time."px; margin-bottom:1px; \">&nbsp;</div>");
                  break;
                }
                $colono++;
              }
            }
          print("</td>");
          
          //研究室（使用者）書き込み
          print("<td bgcolor=white>"); //rgb(242,255,226)
            // スケジュールが存在するかどうかチェックして棒グラフを書き込み
            $colono = 0;
            foreach ($schedule_list as $lineno3 => $line3) {
              list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $line3);
              if ($schedule_date == $year . $month . sprintf("%02d", $day)) {
                $new_line = htmlspecialchars($title, ENT_QUOTES);
                switch ($colono){
                case 0:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #32CD32; font-size: 11px; margin-bottom: 1px; \">$new_line</div>");
                  break;
                case 1:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #ffc0cb; font-size: 11px; margin-bottom: 1px; \">$new_line</div>");
                  break;
                case 2:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #87ceeb; font-size: 11px; margin-bottom: 1px; \">$new_line</div>");
                  break;
                case 3:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #deb887; font-size: 11px; margin-bottom: 1px; \">$new_line</div>");
                  break;
                default:
                  print("<div style=\"border-width: 1px; border-style: solid; border-color: #32CD32; font-size: 11px; margin-bottom: 1px; \">$new_line</div>");
                  break;
                }
                $colono++;
              }
            }
          print("</td></tr>");
        }
        //5行毎に時刻を表示する
        if($lineno%4 == 0 and $lineno != 0){
          echo "<tr><td>設備名</td><td></td>";
          for($i=0;$i<24;$i++){
            echo "<td>$i</td>";
          }
          echo "<td></td><td>研究室（使用者）</td></tr>";
        }
      }
    ?>
    
    <tr>
      <td>設備名</td>
      <td></td>
      <?php
        for($i=0;$i<24;$i++){
          echo "<td>$i</td>";
        }
      ?>
      <td></td>
      <td>研究室（使用者）</td>
    </tr>
    
    <td colspan="1"  width="250"></td>
    <td colspan="26" width="400">時刻</td>
    <td colspan="1"  width="160" ></td>
    
    <tr>
      <th colspan="1" width="250"><a href="schedule_calendar_all.php?date= <?php print(strtotime("-1 day",$date_timestamp)); ?>">前日</a></th>
      <th colspan="26" width="400"><?php print(date("Y", $date_timestamp) . "年" . date("n", $date_timestamp) . "月". date("j", $date_timestamp) . "日"); ?></th>
      <th colspan="1" width="160"><a href="schedule_calendar_all.php?date= <?php print(strtotime("+1 day",$date_timestamp)); ?>">次日</a></th>
    </tr>
  </table>
<div>
<div class="blockc">
</div>
</body>
</html>
