<?php
  // カレンダーの年月をタイムスタンプを使って指定
  date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
  if (isset($_GET["date"]) && $_GET["date"] != "") {
    $date_timestamp = $_GET["date"];
  } elseif (isset($_GET["month"]) && $_GET["month"] != "") {
    $date_timestamp = mktime(0, 0, 0, $_GET["month"], $_GET["day"], $_GET["year"]);
  } else {
    $date_timestamp = time();
  }
  $month = date("m", $date_timestamp);
  $year = date("Y", $date_timestamp);
  //$hour = date("G", time());
  //$minute = date("i", time());
  
  $first_date = mktime(0, 0, 0, $month, 1, $year);
  $last_date = mktime(0, 0, 0, $month + 1, 0, $year);
  
  // 最初の日と最後の日の｢日にち」の部分だけ数字で取り出す
  $first_day = date("j", $first_date);
  $last_day = date("j", $last_date);
  
  // 全ての日の曜日を得る。
  for($day = $first_day; $day <= $last_day; $day++) {
    $day_timestamp = mktime(0, 0, 0, $month, $day, $year); 
    $week[$day] = date("w", $day_timestamp); 
  }
?>

<!DOCTYPE html>
<html xml:lang="ja">
<head>
  <title>カレンダー（設備・共用装置予約システム）</title>
  <style type="text/css">
    a:link {color: #3366FF; background-color: transparent;  text-decoration: none; font-weight: bold;}
    a:visited {color: #2B318F; background-color: transparent;   text-decoration: none; font-weight: bold;}
    a:hover {color: #00BFFF; background-color: transparent;  text-decoration: underline;}
    body {color: #333333; background-color: #FFFFFF;}
    table {border: 1px solid #CCCCCC; border-collapse: collapse;  margin-bottom: 1em;}
    td {border: 1px solid #CCCCCC; width: 2.5em; height: 2.5em;  text-align: right; vertical-align: bottom; padding: 2px;}
    th {border: 1px solid #CCCCCC; color: #333333;  background-color: #F0F0F0; padding: 5px;}
    div.blocka{
      float: left;
      width: 530px;
    }
    div.blockc{
      clear: both;
    }
  </style>
</head>
<body>
<h1>名古屋○○大学　設備・装置共用予約システム<br>カレンダー　［<?php echo htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto")); ?>］</h1>
<div class="blocka">
  <table border="1">
    <tr>
      <th colspan="2"><a href="schedule_calendar.php?date= <?php print(strtotime("-1 month", $first_date)); 
        echo "&\$rcsno=",htmlspecialchars($_GET['$rcsno'], ENT_QUOTES),"&\$name=",htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto")); ?>">前月</a></th>
      <th colspan="3"><?php print(date("Y", $date_timestamp) . "年" . date("n", $date_timestamp) . "月"); ?></th>
      <th colspan="2"><a href="schedule_calendar.php?date= <?php print(strtotime("+1 month", $first_date)); 
        echo "&\$rcsno=",htmlspecialchars($_GET['$rcsno'], ENT_QUOTES),"&\$name=",htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto")); ?>">次月</a></th>
    </tr>
    <tr>
      <th>日(Sun)</th>
      <th>月(Mon)</th>
      <th>火(Tue)</th>
      <th>水(Wed)</th>
      <th>木(Thu)</th>
      <th>金(Fri)</th>
      <th>土(Sat)</th>
    </tr>
    <tr>
      <?php
        // カレンダーの最初の空白部分
        for ($i = 0; $i < $week[$first_day]; $i++) {
          print("<td></td>\n");
        }
        
        // .txtからデータを取得
        $filename = ".\\rcs\\text\\".$_GET['$rcsno']."_reservation.txt";
        $schedule_list = file($filename);
        for ($day = $first_day; $day <= $last_day; $day++) {
          if ($week[$day] == 0) {
            print("</tr>\n<tr>\n");
          }
          
          // スケジュールが存在するかどうかチェックする
          $exist_schedule = false;
          foreach ($schedule_list as $lineno => $line) {
            list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $line);
            if ($schedule_date == $year . $month . sprintf("%02d", $day)) {
              $exist_schedule = true;
            break;
            }
          }
          
          // スケジュールが存在したらリンクをつける。URLに情報が記載。$_GET['xxx']でデータが取得できる
          if ($exist_schedule) {
            $name  = htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto"));
            $rcsno = htmlspecialchars($_GET['$rcsno'], ENT_QUOTES);
            print("<td><a href=\"schedule_calendar.php?\$rcsno=".$rcsno."&\$name=".$name."&year=".$year."&month=".$month."&day=$day\">$day</a></td>\n");
          } else {
            print("<td>$day</td>\n");
          }
        }
        
        // カレンダーの最後の空白部分
        for ($i = $week[$last_day] + 1; $i < 7; $i++) {
          print ("<td></td>\n");
        }
      ?>
    </tr>
  </table>
</div>
<div class="blockb">
  <table border="1" width="350">
    <tr>
      <th>お知らせ（一般）</th>
    </tr>
    <tr height="165">
      <td>
        <?php
          date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
          // 日付の情報をURLから取得できるか調べ、可能なら取得する
          if (isset($_GET["year"])  and $_GET["year"]  !="" and
            isset($_GET["month"]) and $_GET["month"] !="" and
            isset($_GET["day"])   and $_GET["day"]   !=""){
            
            // GETのためにURL出力で表示されるのでここで対処している
            $year  = htmlspecialchars($_GET["year"], ENT_QUOTES);
            $month = htmlspecialchars($_GET["month"], ENT_QUOTES);
            $day   = htmlspecialchars($_GET["day"], ENT_QUOTES);
            
            $title = "　研究室（）内線";
            //$start_hrs = date("G", $date_timestamp); 
            //$start_min = date("i", $date_timestamp); 
            $start_hrs = date("G", time()); 
            $start_min = date("i", time()); 
            $end_hrs   = 17;
            $end_min   = 30;
            $time = 0;
            $body  = "";
            $total_time = 0;
          }else{
          // URLに情報が無い場合、登録画面の日付を本日に指定
            date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
            $date_timestamp = time();
            $day   = date("j", $date_timestamp); 
            $month = date("m", $date_timestamp); 
            $year  = date("Y", $date_timestamp);
            $hrsminsec = date("H", $date_timestamp).date("i", $date_timestamp).date("s", $date_timestamp);
            $title = "　研究室（）内線";
            //$start_hrs = date("G", $date_timestamp);
            //$start_min = date("i", $date_timestamp);
            $start_hrs = date("G", time()); 
            $start_min = date("i", time()); 
            $end_hrs   = 17;
            $end_min   = 30;
            $time = 0;
            $body  = "";
            $total_time = 0;
          }
          if(isset($_POST['key']) and $_POST['key']){
            if(mb_strlen($_POST["key"]) > 40) {
              echo "申し訳ありませんが、40文字までです。<br>";
            } else {
              date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
              $keywords = date("［↓ Y年m月j日　H時i分］\n").htmlspecialchars($_POST['key'], ENT_QUOTES);
              $filename = ".\\rcs\\text\\".htmlspecialchars($_GET['$rcsno'], ENT_QUOTES)."_comment.txt";
              $comment_list = file($filename);
              $fp = fopen($filename, "a");
              fwrite($fp, $keywords."\n");
              fclose($fp);
            }
          }
          $filename = ".\\rcs\\text\\".htmlspecialchars($_GET['$rcsno'], ENT_QUOTES)."_comment.txt";
          $comment_list = file($filename);
          foreach ($comment_list as $lineno => $original_line) {
            if($lineno == sizeof($comment_list)-4){
              //$line = str_replace(array("\r\n", "\r", "\n"), "<br>", $original_line);
              $line = str_replace(array("\r\n", "\r", "\n"), "", $original_line);
              echo "<p align=\"left\">",htmlspecialchars($line, ENT_QUOTES),"</p>\n";
            }
            if($lineno == sizeof($comment_list)-3){
              //$line = str_replace(array("\r\n", "\r", "\n"), "<br>", $original_line);
              $line = str_replace(array("\r\n", "\r", "\n"), "", $original_line);
              echo "<p align=\"left\">",htmlspecialchars($line, ENT_QUOTES),"</p>\n";
            }
            if($lineno == sizeof($comment_list)-2){
              //$line = str_replace(array("\r\n", "\r", "\n"), "<br>", $original_line);
              $line = str_replace(array("\r\n", "\r", "\n"), "", $original_line);
              echo "<p align=\"right\">",htmlspecialchars($line, ENT_QUOTES),"</p>\n";
            }
            if($lineno == sizeof($comment_list)-1){
              //$line = str_replace(array("\r\n", "\r", "\n"), "<br>", $original_line);
              $line = str_replace(array("\r\n", "\r", "\n"), "", $original_line);
              echo "<p align=\"right\">",htmlspecialchars($line, ENT_QUOTES),"</p>\n";
            }
          }
        ?>
      </td>
    </tr>
  </table>
  <table border="1" width="350">
    <tr>
      <th class="page-search">コメント</th>
    </tr>
    <tr>
      <td colspan="1">
        <form method="post" action=<?php echo "schedule_calendar.php?\$rcsno=",htmlspecialchars($_GET['$rcsno'], ENT_QUOTES),
          "&\$name=",htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto")),"&year=",$year,"&month=",$month,"&day=",$day; ?> >
          <input name="key" type="text" size="48" value=""></input>
        </from>
      </td>
    </tr>
  </table>
<div>
<div class="blockc">
</div>
</body>
</html>

<?php
  date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
  // 日付の情報をURLから取得できるか調べ、可能なら取得する
  if (isset($_GET["year"])  and $_GET["year"]  !="" and
    isset($_GET["month"]) and $_GET["month"] !="" and
    isset($_GET["day"])   and $_GET["day"]   !=""){
    
    // GETのためにURL出力で表示されるのでここで対処している
    $year  = htmlspecialchars($_GET["year"], ENT_QUOTES);
    $month = htmlspecialchars($_GET["month"], ENT_QUOTES);
    $day   = htmlspecialchars($_GET["day"], ENT_QUOTES);
    
    $title = "　研究室（）内線";
    //$start_hrs = date("G", $date_timestamp); 
    //$start_min = date("i", $date_timestamp); 
    $start_hrs = date("G", time()); 
    $start_min = date("i", time()); 
    $end_hrs   = 17;
    $end_min   = 30;
    $time = 0;
    $body  = "";
    $total_time = 0;
  }else{
    // URLに情報が無い場合、登録画面の日付を本日に指定
    date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
    $date_timestamp = time();
    $day   = date("j", $date_timestamp); 
    $month = date("m", $date_timestamp); 
    $year  = date("Y", $date_timestamp);
    $hrsminsec = date("H", $date_timestamp).date("i", $date_timestamp).date("s", $date_timestamp);
    $title = "　研究室（）内線";
    //$start_hrs = date("G", $date_timestamp);
    //$start_min = date("i", $date_timestamp);
    $start_hrs = date("G", time()); 
    $start_min = date("i", time()); 
    $end_hrs   = 17;
    $end_min   = 30;
    $time = 0;
    $body  = "";
    $total_time = 0;
  }
  
  //データの並べ替え
  if (isset($_POST["searchType"])) {
    //全装置の一覧の部分は表示が横に並べられなかったのでここに置いている。本来は別が良いと思う。
    if ($_POST["searchType"]=="全装置の一覧"){
      header("Location: http://localhost/schedule_calendar_all.php");
      exit;
    }
    $udw = $_POST["searchType"];
    $filename = ".\\rcs\\text\\".$_GET['$rcsno']."_reservation.txt";
    $schedule_list = file($filename);
    $fp = fopen($filename, "w");
    foreach ($schedule_list as $lineno => $line) {
      list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $line);
      $sc_list[] = array('date_list' => $schedule_date, 'hrsminsec_list' => $hrsminsec, 'contents_list' => "|".$title."|".$start_time."|".$end_time."|".$body."|".$total_time);
    }
    foreach ($sc_list as $lineno => $row) {
      $date_list[$lineno]  = $row['date_list'];
      $hrsminsec_list[$lineno]  = $row['hrsminsec_list'];
      $contents_list[$lineno]  = $row['contents_list'];
    }
    array_multisort($date_list, SORT_ASC, $hrsminsec_list, SORT_ASC,  $sc_list);
    $total_time_temp = 0;
    foreach ($sc_list as $lineno => $row) {
      $date_content  = $row['date_list'];
      $hrsminsec_content  = $row['hrsminsec_list'];
      $contents_content  = $row['contents_list'];
      
      $original_line = $date_content."|".$hrsminsec_content.$contents_content;
      list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $original_line);
      $start_hrs = intval(substr($start_time, 0, 2));
      $start_min = intval(substr($start_time, 2, 2));
      $end_hrs = intval(substr($end_time, 0, 2));
      $end_min = intval(substr($end_time, 2, 2));
      $new_total_time = ($end_hrs - $start_hrs) + ($end_min-$start_min)/60 + $total_time_temp;
      $new_line = $schedule_date."|".$hrsminsec."|".$title."|".$start_time."|".$end_time."|".$body."|".$new_total_time."\n";
      fwrite($fp, $new_line);
      $total_time_temp = $new_total_time;
    }
    fclose($fp);
    
    switch ($udw) {
      case "昇順":
        break;
      case "降順":
        $filename = ".\\rcs\\text\\".$_GET['$rcsno']."_reservation.txt";
        $schedule_list = file($filename);
        $fp = fopen($filename, "w");
        foreach ($schedule_list as $lineno => $line) {
          list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $line);
          $sc_list_desc[] = array('date_list_desc' => $schedule_date, 'hrsminsec_list_desc' => $hrsminsec, 'contents_list_desc' => "|".$title."|".$start_time."|".$end_time."|".$body."|".$total_time);
        }
        foreach ($sc_list_desc as $lineno => $row) {
          $date_list_desc[$lineno]  = $row['date_list_desc'];
          $hrsminsec_list_desc[$lineno]  = $row['hrsminsec_list_desc'];
          $contents_list_desc[$lineno]  = $row['contents_list_desc'];
        }
        array_multisort($date_list_desc, SORT_DESC, $hrsminsec_list, SORT_DESC, $sc_list_desc);
        foreach ($sc_list_desc as $lineno => $row) {
          $date_content_desc  = $row['date_list_desc'];
          $hrsminsec_content_desc  = $row['hrsminsec_list_desc'];
          $contents_content_desc  = $row['contents_list_desc'];
          
          $original_line = $date_content_desc."|".$hrsminsec_content_desc.$contents_content_desc;
          list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $original_line);
          $new_line = $schedule_date."|".$hrsminsec."|".$title."|".$start_time."|".$end_time."|".$body."|".$total_time;
          fwrite($fp, $new_line);
          $total_time_temp = $new_total_time;
        }
        fclose($fp);
        break;
      default:  echo "エラー"; exit;
    }
  fclose($fp);
  $name  = htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto"));
  $rcsno = htmlspecialchars($_GET['$rcsno'], ENT_QUOTES);
  header("Location: http://localhost/schedule_calendar.php?\$rcsno=$rcsno&\$name=$name&year=$year&month=$month&day=$day");
  exit;
  }
  
  //登録データを処理するためのファイルのアドレス
  $filename = ".\\rcs\\text\\".$_GET['$rcsno']."_reservation.txt";
  
  //登録データを削除、GETで受け取っている
  if (isset($_GET["mode"])){
    if ($_GET["mode"]=="delete") {
      $schedule_list = file($filename);
      $fp = fopen($filename, "w");
      $total_time_temp = 0;
      foreach ($schedule_list as $lineno => $original_line) {
        if ($lineno == $_GET["lineno"] and $_GET["mode"]=="delete") {
        } else {
          list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $original_line);
          $start_hrs = intval(substr($start_time, 0, 2));
          $start_min = intval(substr($start_time, 2, 2));
          $end_hrs = intval(substr($end_time, 0, 2));
          $end_min = intval(substr($end_time, 2, 2));
          $new_total_time = ($end_hrs - $start_hrs) + ($end_min-$start_min)/60 + $total_time_temp;
          $new_line = $schedule_date."|".$hrsminsec."|".$title."|".$start_time."|".$end_time."|".$body."|".$new_total_time."\n";
          fwrite($fp, $new_line);
          $total_time_temp = $new_total_time;
        }
      }
      fclose($fp);
      $name  = htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto"));
      $rcsno = htmlspecialchars($_GET['$rcsno'], ENT_QUOTES);
      header("Location: http://localhost/schedule_calendar.php?\$rcsno=$rcsno&\$name=$name&year=$year&month=$month&day=$day");
      exit;
    }
  }
  
  // データが入力されたら登録の処理を開始する
  if (isset($_POST["regist"]) and ($_POST["regist"]=="登録する" or $_POST["regist"]=="更新する") and 
    $_POST["key"]=="" and ($_POST["key"]!="\r" or $_POST["key"]!="\n" or $_POST["key"]!="\r\n")) {
    
    // 入力チェック
    $error_message = array();
    if (isset($_POST["year"]) && is_numeric($_POST["year"]) && $_POST["year"] >= 2017) {
      $year = $_POST["year"];
      
    } else {
      $error_message[] = "年を正しく入力してください。";
    }
    if (isset($_POST["month"]) && is_numeric($_POST["month"]) && $_POST["month"] >= 1 && $_POST["month"] <= 12) {
      $month = $_POST["month"];
    } else {
      $error_message[] = "月を正しく入力してください。";
    }
    if (isset($_POST["day"]) && is_numeric($_POST["day"])  && $_POST["day"] >= 1 && $_POST["day"] <= 32) {
      $day = $_POST["day"];
    } else {
      $error_message[] = "日を正しく入力してください。";
    }
    if (isset($_POST["title"]) && $_POST["title"]) {
      if (strstr($_POST["title"], "|")) {
        $error_message[] = "申し訳ありませんが、研究室（使用者）に|文字は使えません。";
      } elseif(mb_strlen($_POST["title"]) > 15) {
        $error_message[] = "申し訳ありませんが、15文字までしか使えません。";
      } else {
        $title = $_POST["title"];
      }
    } else {
      $error_message[] = "研究室（使用者）を入力してください。";
    }
    
    if (isset($_POST["start_hrs"]) && is_numeric($_POST["start_hrs"]) && $_POST["start_hrs"] >= 0 && $_POST["start_hrs"] < 24) {
      $start_hrs = $_POST["start_hrs"];
    } else {
      $error_message[] = "開始時間（時）を正しく入力してください。";
    }
    if (isset($_POST["start_min"]) && is_numeric($_POST["start_min"]) && $_POST["start_min"] >= 0 && $_POST["start_min"] < 60) {
      $start_min = $_POST["start_min"];
    } else {
      $error_message[] = "開始時間（分）を正しく入力してください。";
    }
    
    if (isset($_POST["end_hrs"]) && is_numeric($_POST["end_hrs"]) && $_POST["end_hrs"] >= 0 && $_POST["end_hrs"] < 24) {
      $end_hrs = $_POST["end_hrs"];
    } else {
      $error_message[] = "終了時間（時）を正しく入力してください。";
    }
    if (isset($_POST["end_min"]) && is_numeric($_POST["end_min"]) && $_POST["end_min"] >= 0 && $_POST["end_min"] < 60) {
      $end_min = $_POST["end_min"];
    } else {
      $error_message[] = "終了時間（分）を正しく入力してください。";
    }
    
    if (isset($_POST["body"]) && $_POST["body"]) {
      if (strstr($_POST["body"], "|")) {
        $error_message[] = "申し訳ありませんが、コメントに|文字は使えません。";
      } elseif(mb_strlen($_POST["body"]) > 140) {
        $error_message[] = "申し訳ありませんが、140文字までしか使えません。";
      } else {
        $body = $_POST["body"];
      }
    } else {
      // $error_message[] = "コメントを入力してください。";
    }
    
    // エラーメッセージを出力する
    if (count($error_message)) {
      print("<div id=\"error-message\"><ul>"); 
      foreach ($error_message as $message) {
        print("<li>".$message."</li>");
      }
      print("</ul></div>");
    }
    
    if (!count($error_message)) {
      // 内容の改行を<br>タグに変換する
      $body = str_replace(array("\r\n", "\r", "\n"), "<br>", $body);
      
      $schedule_date = sprintf("%04d%02d%02d", $year, $month, $day);
      $start_time    = sprintf("%02d%02d", $start_hrs, $start_min);
      $end_time      = sprintf("%02d%02d", $end_hrs, $end_min);
      $new_line = $schedule_date."|".$hrsminsec."|".$title."|".$start_time."|".$end_time."|".$body."|".$total_time."\n";
      
      //登録データの更新と追加、POSTで受け取っている
      if (isset($_POST["lineno"])) {
        //登録データを更新、POSTで受け取っている
        $schedule_list = file($filename);
        $fp = fopen($filename, "w");
        $total_time_temp = 0;
        foreach ($schedule_list as $lineno => $original_line) {
          if ($lineno == $_POST["lineno"]) {
            list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $new_line);
          } else {
            list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $original_line);
          }
          $start_hrs = intval(substr($start_time, 0, 2));
          $start_min = intval(substr($start_time, 2, 2));
          $end_hrs = intval(substr($end_time, 0, 2));
          $end_min = intval(substr($end_time, 2, 2));
          $new_total_time = ($end_hrs - $start_hrs) + ($end_min-$start_min)/60 + $total_time_temp;
          $line = $schedule_date."|".$hrsminsec."|".$title."|".$start_time."|".$end_time."|".$body."|".$new_total_time."\n";
          fwrite($fp, $line);
          $total_time_temp = $new_total_time;
        }
        fclose($fp);
      } else{
        //登録データの追加、POSTで受け取っている
        $schedule_list = file($filename);
        $fp = fopen($filename, "r");
        $last_lineno = sizeof($schedule_list)-1;
        foreach ($schedule_list as $lineno => $original_line) {
          if ($lineno == $last_lineno) {
            list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $last_total_time) = explode("|", $original_line);
          }
        }
        fclose($fp);
        list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $new_line);
        $start_hrs = intval(substr($start_time, 0, 2));
        $start_min = intval(substr($start_time, 2, 2));
        $end_hrs = intval(substr($end_time, 0, 2));
        $end_min = intval(substr($end_time, 2, 2));
        $new_total_time = ($end_hrs - $start_hrs) + ($end_min-$start_min)/60 + $last_total_time;
        $hrsminsec = date("H").date("i").date("s");
        $new_line = $schedule_date."|".$hrsminsec."|".$title."|".$start_time."|".$end_time."|".$body."|".$new_total_time."\n";
        $fp = fopen($filename, "a");
        fwrite($fp, $new_line);
        fclose($fp);
      }
      
      // 一覧画面へリダイレクト
      $name  = htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto"));
      $rcsno = htmlspecialchars($_GET['$rcsno'], ENT_QUOTES);
      header("Location: http://localhost/schedule_calendar.php?\$rcsno=$rcsno&\$name=$name&year=$year&month=$month&day=$day");
      exit;
    }
  } else {
    if (isset($_GET["lineno"])) {
      $lineno = intval($_GET["lineno"]);
      $schedule_list = file($filename);
      $line = $schedule_list[$lineno];
      
      if (!$line) {
        // スケジュールが見つからなかった場合
        print("指定されたスケジュールは見つかりません");
        exit;
      }
      
      list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $line);
      
      $year = intval(substr($schedule_date, 0, 4));
      $month = intval(substr($schedule_date, 4, 2));
      $day = intval(substr($schedule_date, 6, 2));
      
      $start_hrs = intval(substr($start_time, 0, 2));
      $start_min = intval(substr($start_time, 2, 2));
      
      // 変更するを押したときに終了時刻をカレンダーから読み取る
      $end_hrs = intval(substr($end_time, 0, 2));
      $end_min = intval(substr($end_time, 2, 2));
      $timestamp_reservation = mktime($end_hrs, $end_min, 0, $month, $day, $year); 
      $time_reservation = $end_hrs*100+$end_min;
      if( time() <= $timestamp_reservation && $time_reservation <= 2359){
        // 変更するを押したときに終了時刻を現在時刻にする
        $end_hrs = date("G");
        $end_min = date("i");
      }
    }
  }
?>


<!DOCTYPE html>
<html xml:lang="ja">
<head>
<title>スケジュール登録</title>
<style type="text/css">
  h1   {color: #666666; font-size: 1.3em; font-weight: bold;  border-left: 10px solid #99CC99; border-bottom: 2px solid #99CC99;}
  form {color: #333333; background-color: #FFFFFF;}
  label{font-weight: bold; color: #333333;  background-color: transparent;}
  input, textarea {border: none; color: #333333;  background-color: #FFFFFF;}
  #schedule-year  {width: 2.5em; border-bottom: 1px solid #000000; font-size: 1em;}
  #schedule-month {width: 1.5em; border-bottom: 1px solid #000000; font-size: 1em;}
  #schedule-day   {width: 1.5em; border-bottom: 1px solid #000000; font-size: 1em;}
  #label-year,  #label-month, #label-day {margin-right: 5px;}
  #label-title, #label-hrs, #label-min {margin-right: 5px;}
  #schedule-time-title {width: 3em; border-bottom: 1px solid #000000; font-size: 1em;}
  #schedule-hrs   {width: 1.5em; border-bottom: 1px solid #000000; font-size: 1em;}
  #schedule-min   {width: 1.5em; border-bottom: 1px solid #000000; font-size: 1em;}
  #schedule-title {margin-bottom: 10px; width: 20em;  border-bottom: 1px solid #000000; font-size: 1em;}
  #schedule-body  {width: 34em; height: 3em; border: 1px solid #000000;}
  #regist {font-weight: bold; padding: 3px; border-top: 3px double #CCCCCC; border-right: 3px double #333333;
   border-bottom: 3px double #333333; border-left: 3px double #CCCCCC; color: #333333; background-color: #EDECEC;} 
  #error-message  {font-weight: bold; color: #DD5757; background-color: transparent;}
  #error-message li {list-style: circle; line-height: 1.5;}
  
  div.blocka{
    float: left;
    width: 530px;
  }
  div.blockc{
    clear: both;
  }
</style>
</head>
<body>

<?php
  date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
  echo "<h1>スケジュール登録",date("　［現在時刻： Y年m月j日　H時i分］（最新の情報に更新で時刻が更新）") ,"</h1>";
?>

<div class="blocka">
  <form action=<?php echo "schedule_calendar.php?\$rcsno=",htmlspecialchars($_GET['$rcsno'], ENT_QUOTES),
    "&\$name=",htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto")),"&year=",$year,"&month=",$month,"&day=",$day; ?> method="post">
    <label for="schedule-time-title" id="label-title">登録日：</label>
    <input type="text" name="year"   id="schedule-year"  value="<?php print(htmlspecialchars($year, ENT_QUOTES)); ?>" />
    <label for="schedule-year"       id="label-year" >年</label>
    <input type="text" name="month"  id="schedule-month" value="<?php $new_month = htmlspecialchars($month, ENT_QUOTES); printf("%-d",$new_month); ?>" />
    <label for="schedule-month"      id="label-month">月</label>
    <input type="text" name="day"    id="schedule-day"   value="<?php $new_day   = htmlspecialchars($day, ENT_QUOTES);   printf("%-d",$new_day); ?>"   />
    <label for="schedule-day"        id="label-day"  >日</label>
    
    <dl>
      <dt>
        <label for="schedule-title" id="label-title">研究室（使用者）</label>
        <input type="text" name="title" id="schedule-title" value="<?php print(htmlspecialchars($title, ENT_QUOTES)); ?>" />
      </dt>
      
      <dt>
        <label for="schedule-time-title" id="label-title">開始時刻：</label>
        
        <input type="text" name="start_hrs" id="schedule-hrs"  value="<?php $new_start_hrs = htmlspecialchars($start_hrs, ENT_QUOTES); printf("%-d",$new_start_hrs); ?>" />
        <label for="schedule-hrs" id="label-hrs">時</label>
        
        <input type="text" name="start_min" id="schedule-min"  value="<?php $new_start_min = htmlspecialchars($start_min, ENT_QUOTES); printf("%-d",$new_start_min); ?>" />
        <label for="schedule-min" id="label-hrs">分</label>
        
        <label for="schedule-time-title" id="label-title">　終了時刻：</label>
        
        <input type="text" name="end_hrs" id="schedule-hrs"  value="<?php $new_end_hrs = htmlspecialchars($end_hrs, ENT_QUOTES); printf("%-d",$new_end_hrs); ?>" />
        <label for="schedule-hrs" id="label-hrs">時</label>
        
        <input type="text" name="end_min" id="schedule-min"  value="<?php $new_end_min = htmlspecialchars($end_min, ENT_QUOTES); printf("%-d",$new_end_min); ?>" />
        <label for="schedule-min" id="label-hrs">分</label>
        
        
        <?php
          if (isset($_GET["lineno"]) and $_GET["mode"]=="edit") {
            ?>
            <input type="hidden" name="lineno" id="lineno" value="<?php print(htmlspecialchars($lineno, ENT_QUOTES)); ?>">
            <input type="submit" name="regist" id="regist" value="更新する" />
            <?php
          } else {
            ?>
            <input type="submit" name="regist" id="regist" value="登録する" />
            <?php
          }
        ?>
      </dt>
      
      <dt>
        <label for="schedule-body" id="labe-body">コメント</label>
      </dt>
      <dd>
        <textarea name="body" id="schedule-body"><?php echo htmlspecialchars($body, ENT_QUOTES); ?></textarea>
      </dd>
    </dl>
  </form>
</div>
<div class="blockb">
  <table border="1" width="350">
    <tr>
      <th class="page-search">お知らせ（HP管理者）</th>
    </tr>
    <tr height="110">
      <td>
        <p align="left">
          スケジュールの入力文字数は140字までです<br></br>
          合計(h)は装置のトータルの使用時間です<br></br>
          英数字は適宜改行してください
        </p>
      </td>
    </tr>
  </table>
</div>
  <div class="blockc">
</div>
</body>
</html>


<!DOCTYPE html>
<html xml:lang="ja">
<head>
<title>スケジュール一覧</title>
<style type="text/css">
  a:link {color: #3366FF; background-color: transparent; text-decoration: none; font-weight: bold;}
  a:visited {color: #2B318F; background-color: transparent; text-decoration: none; font-weight: bold;}
  a:hover {color: #00BFFF; background-color: transparent; text-decoration: underline;}
  body {color: #333333; background-color: #FFFFFF;}
  table {border: 1px solid #CCCCCC; border-collapse: collapse; margin-bottom: 1em;}
  td {border: 1px solid #CCCCCC; height: 2.5em;
      vertical-align: middle; padding-left: 1em; padding-top: 2px; 
      padding-right: 1em; padding-bottom: 2px;}
  th {border: 1px solid #CCCCCC; color: #333333; background-color: #F0F0F0; padding: 5px;}
  #regist1 {border-collapse: collapse;
  margin-left:auto; 
  margin-right:auto; 
  margin-bottom:2px; 
  border-collapse: collapse;
  border-style: solid;
  border-width: 1px;
  border-color: #888888;
  font-size:10.5pt;
  background-color:#dddddd;
</style>
</head>
<body>
<h1>スケジュール一覧</h1>
<form method="post" action=<?php echo "schedule_calendar.php?\$rcsno=",htmlspecialchars($_GET['$rcsno'], ENT_QUOTES),
          "&\$name=",htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto")),"&year=",$year,"&month=",$month,"&day=",$day; ?> >
  <input name="searchType" type="submit" id="regist1" value="昇順">
  <input name="searchType" type="submit" id="regist1" value="降順">
  <input name="searchType" type="submit" id="regist1" value="全装置の一覧">
</form>
<table border="1"; >
  <tr>
    <th width=" 8%";>日付</th> 
    <th width="14%";>研究室（使用者）</th> 
    <th width=" 8%";>開始時間</th>
    <th width=" 8%";>終了時間</th>
    <th width=" 6%";>時間（h）</th>
    <th width="30%";>コメント</th>
    <th width=" 9%";>編集</th>
    <th width=" 9%";>削除</th>
    <th width=" 6%";>合計（h）</th>
  </tr>

<?php 
  // 日付の情報をURLから取得できるか調べ、可能なら取得する
  if (isset($_GET["year"])  and $_GET["year"]  !="" and
      isset($_GET["month"]) and $_GET["month"] !="" and
      isset($_GET["day"])   and $_GET["day"]   !=""){
    // GETのためにURL出力で表示されるのでここで対処している
    $year  = htmlspecialchars($_GET["year"], ENT_QUOTES);
    $month = htmlspecialchars($_GET["month"], ENT_QUOTES);
    $day   = htmlspecialchars($_GET["day"], ENT_QUOTES);
    //$start_hrs = date("G", $date_timestamp);
    //$start_min = date("i", $date_timestamp);
    $start_hrs = date("G", time()); 
    $start_min = date("i", time()); 
    $end_hrs   = 17;
    $end_min   = 30;
    $time = 0;
    $body  = "";
    $total_time = 0;
  }else{
    // URLに情報が無い場合、登録画面の日付を本日に指定
    date_default_timezone_set('Asia/Tokyo'); //日本の標準時間を取得
    $date_timestamp = time();
    $day = date("j", $date_timestamp);
    $month = date("m", $date_timestamp); 
    $year = date("Y", $date_timestamp);
    $hrsminsec = date("H", $date_timestamp).date("i", $date_timestamp).date("s", $date_timestamp);
    //$start_hrs = date("G", $date_timestamp);
    //$start_min = date("i", $date_timestamp);
    $start_hrs = date("G", time()); 
    $start_min = date("i", time()); 
    $end_hrs   = 17;
    $end_min   = 30;
    $time = 0;
    $body  = "";
    $total_time = 0;
  }
  
  // 本日またはカレンダーで選んだ日付のリストを表示
  foreach ($schedule_list as $lineno => $line) {
    list($schedule_date, $hrsminsec, $title, $start_time, $end_time, $body, $total_time) = explode("|", $line);
    if ($schedule_date == date("Ymd", mktime(0, 0, 0, $month, $day, $year))) {
      $start_hrs = intval(substr($start_time, 0, 2));
      $start_min = intval(substr($start_time, 2, 2));
      
      $end_hrs = intval(substr($end_time, 0, 2));
      $end_min = intval(substr($end_time, 2, 2));
      
      print("<tr>\n");
      print("<td>$schedule_date</td>\n");
      echo "<td>", $title, "</td>\n"; 
      echo "<td>", sprintf("%02d:%02d", $start_hrs, $start_min),"</td>\n";
      echo "<td>", sprintf("%02d:%02d", $end_hrs, $end_min),"</td>\n";
      $time = ($end_hrs - $start_hrs) + ($end_min-$start_min)/60;
      echo "<td>", round( $time, 1, PHP_ROUND_HALF_EVEN),"</td>\n";
      //改行をうまく表示させるための対策
      $body_correct1 = str_replace(array("<br>"), "\n", $body);
      $body_correct2 = htmlspecialchars($body_correct1, ENT_QUOTES);
      $body_correct3 = str_replace(array("\n"), "<br>", $body_correct2);
      echo "<td>", $body_correct3, "</td>\n";
      $name = htmlspecialchars(mb_convert_encoding($_GET['$name'], "UTF-8", "auto"));
      $rcsno = htmlspecialchars($_GET['$rcsno'], ENT_QUOTES);
      print("<td><a href=\"schedule_calendar.php?\$rcsno=$rcsno&\$name=$name&year=$year&month=$month&day=$day&lineno=$lineno&mode=edit\">変更する</a></td>\n");
      print("<td><a href=\"schedule_calendar.php?\$rcsno=$rcsno&\$name=$name&year=$year&month=$month&day=$day&lineno=$lineno&mode=delete\">削除する</a></td>\n");
      echo "<td>", round( $total_time, 1, PHP_ROUND_HALF_EVEN),"</td>\n";
      print("</tr>\n");
    }
  }
?>
</table>
</body>
</html>
